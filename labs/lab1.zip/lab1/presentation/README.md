# Markdown based  Academic Presentation

## Download repository

git clone https://github.com/yamadharma/academic-presentation-markdown-template.git

